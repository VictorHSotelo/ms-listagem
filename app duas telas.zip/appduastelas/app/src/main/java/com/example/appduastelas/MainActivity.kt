class MainActivity : AppCompatActivity(), View.OnClickListener
{

    private lateinit var binding : ActivityMainBinding
    private lateinit var securityPreferences:
    SecurityPreferences
    private

}
